import '../css/style.css';

console.log('Čistá šablona projektu');
